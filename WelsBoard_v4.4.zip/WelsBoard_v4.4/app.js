<script>
// ============================================================
// Welsford_KanBan - app.js
// Client-side application logic.
// Version: 4.4
// ============================================================

// ── GLOBALS ───────────────────────────────────────────────────
var CLIENT_CONFIG     = {};
var COLUMNS           = [];
var allTasks          = [];
var allSources        = [];
var memberMap         = {};
var sectionWordCounts = {};
var sectionCeilings    = {}; // user-set per-section ceiling word counts
var activeFilter      = 'all';
var srcFilter         = 'all';
var draggedId         = null;
var currentEngine     = 'google';
var allAuditEntries   = [];
var liveSections      = []; // Drive scan result, used by report tab

// ── IDENTITY ──────────────────────────────────────────────────
var KB_IDENTITY_KEY = 'kb_identity';
function getActor() {
  return localStorage.getItem(KB_IDENTITY_KEY) || 'Unknown';
}

// ── BOOT ─────────────────────────────────────────────────────
function bootApp(cfg) {
  CLIENT_CONFIG = cfg;
  COLUMNS       = cfg.columns || [];

  // Per-board localStorage key
  KB_IDENTITY_KEY = 'kb_id_' + (cfg.spreadsheetId || 'default');

  // Branding
  var logoMark = document.getElementById('logo-mark');
  if (logoMark) {
    if (cfg.logoImageUrl && cfg.logoImageUrl.trim()) {
      logoMark.innerHTML = '<img src="' + cfg.logoImageUrl + '" alt="Logo" style="width:100%;height:100%;object-fit:cover">';
    } else {
      logoMark.textContent = cfg.logoText || 'KB';
    }
  }
  var ht = document.getElementById('header-title');
  if (ht) ht.textContent = cfg.projectName || 'Task Board';
  var hs = document.getElementById('header-sub');
  if (hs) hs.textContent = (cfg.projectSubtitle || '') + ' - Group Task Board';
  var hm = document.getElementById('header-meta');
  if (hm) hm.innerHTML = (cfg.headerChips || []).map(function (c) {
    return '<div class="meta-chip' + (c.accent ? ' accent' : '') + '">' + c.label + '</div>';
  }).join('');

  // Word count bar
  var wcChips = document.getElementById('wc-chips');
  if (wcChips) wcChips.innerHTML = (cfg.sections || [])
    .filter(function (s) { return s.target > 0; })
    .map(function (s) { return '<span class="wc-chip">' + s.name + ' ~' + s.target + '</span>'; })
    .join('');
  var wcTotal = document.getElementById('wc-total-label');
  if (wcTotal) wcTotal.textContent = 'Total: ' + (cfg.reportWordTarget || 0) + ' words';

  // Section dropdowns
  var sectionOpts = (cfg.sections || []).map(function (s) {
    return '<option value="' + s.name + '">' + s.name + '</option>';
  }).join('');
  ['f-section', 'e-section'].forEach(function (id) {
    var el = document.getElementById(id);
    if (el) el.innerHTML = sectionOpts;
  });

  var srcSel = document.getElementById('src-section-select');
  if (srcSel) srcSel.innerHTML = sectionOpts + '<option value="General">General</option>';
  var srcFilters = document.getElementById('src-section-filters');
  if (srcFilters) {
    srcFilters.innerHTML = (cfg.sections || [])
      .filter(function (s) { return s.target > 0; })
      .map(function (s) {
        return '<button class="src-filter-btn" onclick="filterSources(\'' + s.name.replace(/'/g,"\\'") + '\',this)">' + s.name + '</button>';
      }).join('');
  }

  var ul = document.getElementById('upload-link');
  if (ul) ul.href = cfg.submissionsFolderUrl || '#';
  var dl = document.getElementById('docs-folder-link');
  if (dl) dl.href = cfg.documentsFolderUrl || '#';

  var mt = document.getElementById('meet-title');
  if (mt) mt.value = (cfg.projectName || 'Group') + ' Sync';

  // Modal backdrops
  ['addModal','editTaskModal','viewNoteModal','noteModal','srcModal','identityModal'].forEach(function (id) {
    var el = document.getElementById(id);
    if (el) el.addEventListener('click', function (e) {
      if (id === 'identityModal') return; // not dismissable
      if (e.target !== el) return;
      if (id === 'editTaskModal') {
        // Save draft before closing on backdrop click
        saveDraftAndClose();
      } else {
        el.classList.remove('open');
      }
    });
  });

  document.addEventListener('click', function () {
    document.querySelectorAll('.dl-edit-panel.open').forEach(function (p) { p.classList.remove('open'); });
  });

  renderDorkButtons();
  loadDeadlines();
  loadMembers(function () { checkIdentity(); });
}

// ── IDENTITY ──────────────────────────────────────────────────
function checkIdentity() {
  var stored = localStorage.getItem(KB_IDENTITY_KEY);
  if (stored && stored.trim()) {
    renderIdentityBadge(stored);
    loadTasks();
  } else {
    showIdentityPicker();
  }
}

function showIdentityPicker() {
  var modal = document.getElementById('identityModal');
  if (!modal) { loadTasks(); return; }
  var sel     = document.getElementById('identity-select');
  var inp     = document.getElementById('identity-input');
  var members = Object.values(memberMap);
  if (members.length > 0) {
    if (sel) {
      sel.style.display = 'block';
      sel.innerHTML = '<option value="">-- Select your name --</option>' +
        members.map(function (n) { return '<option value="' + escHtml(n) + '">' + escHtml(n) + '</option>'; }).join('');
    }
    if (inp) inp.style.display = 'none';
  } else {
    if (sel) sel.style.display = 'none';
    if (inp) { inp.style.display = 'block'; inp.placeholder = 'Enter your name'; inp.value = ''; }
  }
  modal.classList.add('open');
}

function confirmIdentity() {
  var sel    = document.getElementById('identity-select');
  var inp    = document.getElementById('identity-input');
  var chosen = '';
  if (sel && sel.style.display !== 'none') {
    chosen = sel.value;
  } else if (inp && inp.style.display !== 'none') {
    chosen = (inp.value || '').trim();
  }
  if (!chosen) {
    var err = document.getElementById('identity-error');
    if (err) { err.textContent = 'Please select or enter your name.'; err.style.display = 'block'; }
    return;
  }
  localStorage.setItem(KB_IDENTITY_KEY, chosen);
  var modal = document.getElementById('identityModal');
  if (modal) modal.classList.remove('open');
  renderIdentityBadge(chosen);
  loadTasks();
}

function renderIdentityBadge(name) {
  var badge = document.getElementById('identity-badge');
  if (!badge) return;
  // No switch button in 4.2 -- identity is set once per session
  badge.innerHTML =
    '<span style="font-size:11px;color:var(--text3);font-family:\'DM Mono\',monospace">Logged in as</span> ' +
    '<span style="font-size:12px;color:var(--accent);font-weight:600">' + escHtml(name) + '</span>';
  badge.style.display = 'flex';
  badge.style.alignItems = 'center';
  badge.style.gap = '4px';
}

// ── SECTION COLOR ─────────────────────────────────────────────
function secColorVar(section) {
  var match = (CLIENT_CONFIG.sections || []).find(function (s) { return s.name === section; });
  return 'var(--sec-' + (match ? (match.colorIdx || 0) : 5) + ')';
}

// ============================================================
// MARKDOWN PARSER
// ============================================================
function parseMarkdown(md) {
  if (!md) return '';
  var s = md.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  s = s.replace(/```([a-z]*)\n?([\s\S]*?)```/gim, function (_, lang, code) {
    return '<pre><code' + (lang ? ' class="lang-' + lang + '"' : '') + '>' + code.trim() + '</code></pre>\n';
  });
  s = s.replace(/~~~([a-z]*)\n?([\s\S]*?)~~~/gim, function (_, lang, code) {
    return '<pre><code' + (lang ? ' class="lang-' + lang + '"' : '') + '>' + code.trim() + '</code></pre>\n';
  });
  s = s.replace(/^(---|\*\*\*|___)\s*$/gim, '<hr>');
  s = s.replace(/^######\s+(.+)$/gim, '<h6>$1</h6>');
  s = s.replace(/^#####\s+(.+)$/gim,  '<h5>$1</h5>');
  s = s.replace(/^####\s+(.+)$/gim,   '<h4>$1</h4>');
  s = s.replace(/^###\s+(.+)$/gim,    '<h3>$1</h3>');
  s = s.replace(/^##\s+(.+)$/gim,     '<h2>$1</h2>');
  s = s.replace(/^#\s+(.+)$/gim,      '<h1>$1</h1>');
  s = s.replace(/^&gt;\s?(.+)$/gim, '<blockquote>$1</blockquote>');
  s = s.replace(/<\/blockquote>\n<blockquote>/gim, '\n');
  s = s.replace(/((?:^.+\|.+\n)+)/gim, function (block) {
    var rows = block.trim().split('\n');
    if (rows.length < 2) return block;
    if (!/^[\|\s\-:]+$/.test(rows[1])) return block;
    var html = '<table>';
    rows.forEach(function (row, i) {
      if (i === 1) return;
      var cells = row.replace(/^\||\/$/g,'').split('|');
      var tag = i === 0 ? 'th' : 'td';
      html += '<tr>' + cells.map(function (c) { return '<' + tag + '>' + c.trim() + '</' + tag + '>'; }).join('') + '</tr>';
    });
    html += '</table>\n';
    return html;
  });
  s = processLists_(s);
  s = s.replace(/`([^`]+)`/g, '<code>$1</code>');
  s = s.replace(/\*\*\*(.+?)\*\*\*/gim, '<strong><em>$1</em></strong>');
  s = s.replace(/___(.+?)___/gim,        '<strong><em>$1</em></strong>');
  s = s.replace(/\*\*(.+?)\*\*/gim, '<strong>$1</strong>');
  s = s.replace(/__(.+?)__/gim,      '<strong>$1</strong>');
  s = s.replace(/\*([^*\n]+)\*/gim, '<em>$1</em>');
  s = s.replace(/_([^_\n]+)_/gim,   '<em>$1</em>');
  s = s.replace(/~~(.+?)~~/gim, '<del>$1</del>');
  s = s.replace(/\+\+(.+?)\+\+/gim, '<u>$1</u>');
  s = s.replace(/\[([^\]]+)\]\(([^)]+)\)/gim, '<a href="$2" target="_blank" rel="noopener">$1</a>');
  var lines = s.split('\n');
  var out   = [];
  var inPre = false;
  lines.forEach(function (line) {
    if (line.startsWith('<pre')) { inPre = true; }
    if (inPre) { out.push(line); if (line.includes('</pre>')) inPre = false; return; }
    var trimmed = line.trim();
    if (!trimmed) { out.push(''); return; }
    if (/^<(h[1-6]|ul|ol|li|table|tr|th|td|blockquote|hr|pre|div|p)/.test(trimmed)) {
      out.push(trimmed);
    } else {
      out.push('<p>' + trimmed + '</p>');
    }
  });
  return out.join('\n').replace(/(<\/p>|<\/li>|<\/ul>|<\/ol>|<\/table>|<hr>)\n\n+/g, '$1\n');
}

function processLists_(s) {
  var lines = s.split('\n'); var result = []; var i = 0;
  while (i < lines.length) {
    var line = lines[i];
    if (/^(\s*)([-*+])\s+(.+)$/.test(line)) {
      var ll = [];
      while (i < lines.length && /^(\s*)([-*+])\s+(.+)$/.test(lines[i])) { ll.push(lines[i]); i++; }
      result.push(buildList_(ll, false));
    } else if (/^(\s*)\d+\.\s+(.+)$/.test(line)) {
      var ll2 = [];
      while (i < lines.length && /^(\s*)\d+\.\s+(.+)$/.test(lines[i])) { ll2.push(lines[i]); i++; }
      result.push(buildList_(ll2, true));
    } else { result.push(line); i++; }
  }
  return result.join('\n');
}

function buildList_(lines, ordered) {
  var tag = ordered ? 'ol' : 'ul';
  var html = '<' + tag + '>';
  lines.forEach(function (line) {
    var m = ordered ? line.match(/^(\s*)\d+\.\s+(.+)$/) : line.match(/^(\s*)([-*+])\s+(.+)$/);
    if (m) html += '<li>' + (ordered ? m[2] : m[3]) + '</li>';
  });
  return html + '</' + tag + '>';
}

function plainPreview(text, maxLen) {
  if (!text) return '';
  var plain = text
    .replace(/#{1,6}\s/g, '')
    .replace(/\*\*/g, '').replace(/\*/g, '')
    .replace(/~~|__|\+\+/g, '')
    .replace(/`/g, '')
    .replace(/^[-*+]\s/gm, '')
    .replace(/^\d+\.\s/gm, '')
    .replace(/\n/g, ' ').trim();
  return plain.length > maxLen ? plain.substring(0, maxLen) + '...' : plain;
}

// ── MARKDOWN TOOLBAR ──────────────────────────────────────────
function applyFormat(taId, syntax, block) {
  var ta = document.getElementById(taId);
  if (!ta) return;
  var s = ta.selectionStart, e = ta.selectionEnd;
  var sel = ta.value.substring(s, e);
  var rep = block ? syntax + (sel || 'text') : syntax + (sel || 'text') + syntax;
  ta.value = ta.value.substring(0, s) + rep + ta.value.substring(e);
  ta.focus(); ta.setSelectionRange(s + rep.length, s + rep.length);
}
function insertAtCursor(taId, text) {
  var ta = document.getElementById(taId);
  if (!ta) return;
  var s = ta.selectionStart;
  ta.value = ta.value.substring(0, s) + text + ta.value.substring(s);
  ta.focus(); ta.setSelectionRange(s + text.length, s + text.length);
}
function mdToolbar(id) {
  return '<div class="md-toolbar">' +
    '<button type="button" class="md-btn bold"   onclick="applyFormat(\'' + id + '\',\'**\',false)" title="Bold">B</button>' +
    '<button type="button" class="md-btn italic" onclick="applyFormat(\'' + id + '\',\'*\',false)"  title="Italic">I</button>' +
    '<button type="button" class="md-btn" onclick="applyFormat(\'' + id + '\',\'~~\',false)" title="Strikethrough" style="text-decoration:line-through">S</button>' +
    '<div class="md-btn separator"></div>' +
    '<button type="button" class="md-btn" onclick="applyFormat(\'' + id + '\',\'## \',true)" title="Heading">H</button>' +
    '<button type="button" class="md-btn" onclick="insertAtCursor(\'' + id + '\',\'\\n- \')" title="Bullet list">&#8226; List</button>' +
    '<button type="button" class="md-btn" onclick="insertAtCursor(\'' + id + '\',\'\\n1. \')" title="Numbered list">1. List</button>' +
    '<button type="button" class="md-btn" onclick="insertAtCursor(\'' + id + '\',\'\\n| Col1 | Col2 |\\n|------|------|\\n| Cell | Cell |\\n\')" title="Table">Table</button>' +
    '<div class="md-btn separator"></div>' +
    '<button type="button" class="md-btn" onclick="applyFormat(\'' + id + '\',\'`\',false)" title="Inline code" style="font-family:monospace">Code</button>' +
    '<button type="button" class="md-btn" onclick="insertAtCursor(\'' + id + '\',\'\\n```\\n\\n```\\n\')" title="Code block" style="font-family:monospace">Block</button>' +
    '<button type="button" class="md-btn" onclick="insertAtCursor(\'' + id + '\',\'\\n> \')" title="Blockquote">&ldquo;</button>' +
  '</div>';
}

// ── DEADLINE BANNER ───────────────────────────────────────────
function daysUntil(dateStr) {
  var t = new Date(); t.setHours(0,0,0,0);
  var d = new Date(dateStr); d.setHours(0,0,0,0);
  return Math.ceil((d - t) / 86400000);
}
function urgencyClass(days) { return days <= 14 ? 'urgent' : days <= 30 ? 'soon' : 'ok'; }
function countdownText(days) {
  if (days < 0)   return Math.abs(days) + 'd overdue';
  if (days === 0)  return 'Today';
  return days + ' day' + (days === 1 ? '' : 's');
}
function formatDisplayDate(dateStr) {
  if (!dateStr) return '';
  return new Date(dateStr).toLocaleDateString('en-AU', { day:'numeric', month:'short', year:'numeric' });
}
function renderDeadlines(deadlines) {
  var container = document.getElementById('deadline-chips');
  if (!container) return;
  if (!deadlines || deadlines.length === 0) {
    container.innerHTML = '<span style="font-size:11px;color:var(--text3);font-family:\'DM Mono\',monospace">No deadlines set</span>';
    return;
  }
  var sorted = deadlines.slice().sort(function (a,b) { return new Date(a.date) - new Date(b.date); });
  container.innerHTML = sorted.map(function (dl, i) {
    var days = daysUntil(dl.date);
    var urg  = urgencyClass(days);
    var safe = dl.label.replace(/'/g, "\\'");
    return '<div class="deadline-chip ' + urg + '" id="dlchip-' + i + '">' +
      '<span class="dl-name">'      + dl.label + '</span>' +
      '<span class="dl-date">'      + formatDisplayDate(dl.date) + '</span>' +
      '<span class="dl-countdown">' + countdownText(days) + '</span>' +
      '<button class="dl-edit-btn" onclick="toggleDeadlineEdit(event,' + i + ',\'' + safe + '\',\'' + dl.date + '\')">&#x270E;</button>' +
      '<div class="dl-edit-panel" id="dl-edit-' + i + '">' +
        '<label>Label</label><input type="text" id="dl-lbl-' + i + '" value="' + dl.label + '">' +
        '<label>Date</label><input type="date" id="dl-date-' + i + '" value="' + dl.date + '">' +
        '<div class="dl-edit-actions">' +
          '<button class="dl-btn-delete" onclick="deleteDeadlineItem(event,\'' + safe + '\')">Delete</button>' +
          '<div style="display:flex;gap:6px">' +
            '<button class="dl-btn-cancel" onclick="toggleDeadlineEdit(event,' + i + ')">Cancel</button>' +
            '<button class="dl-btn-save" onclick="saveDeadlineItem(event,' + i + ',\'' + safe + '\')">Save</button>' +
          '</div>' +
        '</div>' +
      '</div>' +
    '</div>';
  }).join('');
}
function toggleDeadlineEdit(e, idx) {
  e.stopPropagation();
  var panel  = document.getElementById('dl-edit-' + idx);
  var isOpen = panel.classList.contains('open');
  document.querySelectorAll('.dl-edit-panel.open').forEach(function (p) { p.classList.remove('open'); });
  if (!isOpen) panel.classList.add('open');
}
function saveDeadlineItem(e, idx, oldLabel) {
  e.stopPropagation();
  var label = document.getElementById('dl-lbl-' + idx).value.trim();
  var date  = document.getElementById('dl-date-' + idx).value;
  if (!label || !date) return;
  google.script.run.withSuccessHandler(loadDeadlines).saveDeadline(label, date, getActor());
}
function deleteDeadlineItem(e, label) {
  e.stopPropagation();
  if (!confirm('Delete deadline "' + label + '"?')) return;
  google.script.run.withSuccessHandler(loadDeadlines).deleteDeadline(label, getActor());
}
function openAddDeadline() {
  var label = prompt('Deadline label (e.g. Final submission):');
  if (!label) return;
  var date  = prompt('Date (YYYY-MM-DD):');
  if (!date) return;
  google.script.run.withSuccessHandler(loadDeadlines).saveDeadline(label.trim(), date.trim(), getActor());
}
function loadDeadlines() {
  google.script.run.withSuccessHandler(function (dl) {
    if (!dl || dl.error) return;
    renderDeadlines(dl);
  }).getDeadlines();
}

// ── BOARD ─────────────────────────────────────────────────────
function priChip(p) {
  if (!p) return '';
  var cls = p === 'High' ? 'pri-high' : p === 'Low' ? 'pri-low' : 'pri-med';
  return '<span class="chip chip-' + cls + '">' + p + '</span>';
}
function renderBoard(tasks) {
  var filtered = tasks.filter(function (t) {
    if (activeFilter === 'all')  return true;
    if (activeFilter === 'High') return t.Priority === 'High';
    return t.Owner && t.Owner.toLowerCase().includes(activeFilter.toLowerCase());
  });
  var html = '<div class="board-wrap"><div class="board">';
  COLUMNS.forEach(function (col) {
    var colTasks = filtered.filter(function (t) { return t.Status === col.id; });
    html += '<div class="column">' +
      '<div class="col-header ' + col.cls + '">' +
        '<span class="col-title ' + col.cls + '">' + col.label + '</span>' +
        '<span class="col-count">' + colTasks.length + '</span>' +
      '</div>' +
      '<div class="col-body" id="col-' + col.id.replace(/ /g,'-') + '"' +
        ' ondragover="onDragOver(event)" ondrop="onDrop(event,\'' + col.id + '\')" ondragleave="onDragLeave(event)">';
    if (colTasks.length === 0) html += '<div class="empty-col">No tasks</div>';
    colTasks.forEach(function (t) {
      var tid   = t.ID;
      var color = secColorVar(t.Section);
      html += '<div class="card" draggable="true" id="card-' + tid + '" style="--card-sec-color:' + color + '"' +
        ' ondragstart="onDragStart(event,\'' + tid + '\')" ondragend="onDragEnd(event)">' +
        '<button class="card-edit-toggle" onclick="openEditModal(event,\'' + tid + '\')" title="Edit">&#x270E;</button>' +
        '<div class="card-section" style="color:' + color + '">' + escHtml(t.Section) + '</div>' +
        '<div class="card-title">' + escHtml(t.Title) + '</div>' +
        '<div class="card-footer">' +
          '<span class="card-owner">' + escHtml(t.Owner || 'Unassigned') + '</span>' +
          '<span class="card-due">'   + escHtml(t.DueDate || '') + '</span>' +
        '</div>' +
        '<div class="card-chips">' +
          (t.WordTarget ? '<span class="chip chip-words">' + t.WordTarget + 'w</span>' : '') +
          priChip(t.Priority) +
        '</div>' +
        (t.Notes
          ? '<div class="card-notes" style="cursor:pointer;"' +
              ' onclick="openViewNoteModal(event,\'' + tid + '\')"' +
              ' onmouseenter="showCardTooltip(event,\'' + tid + '\')"' +
              ' onmouseleave="hideCardTooltip()">' +
              '<div class="card-notes-preview">' + escHtml(plainPreview(t.Notes, 80)) + '</div>' +
            '</div>'
          : '') +
      '</div>';
    });
    html += '</div></div>';
  });
  html += '</div></div>';
  document.getElementById('board-container').innerHTML = html;
  updateProgress();
}
function escHtml(str) {
  return String(str || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}
function buildSectionOptions(selected) {
  return (CLIENT_CONFIG.sections || []).map(function (s) {
    return '<option' + (s.name === selected ? ' selected' : '') + '>' + s.name + '</option>';
  }).join('');
}
function loadTasks() {
  google.script.run
    .withSuccessHandler(function (tasks) { allTasks = tasks || []; renderBoard(allTasks); })
    .withFailureHandler(function (err) {
      document.getElementById('board-container').innerHTML =
        '<div class="loading" style="color:var(--pri-high)">Error loading tasks: ' + err.message + '</div>';
    })
    .getTasks();
}
function setFilter(f, btn) {
  activeFilter = f;
  document.querySelectorAll('.filter-btn').forEach(function (b) { b.classList.remove('active'); });
  if (btn) btn.classList.add('active');
  renderBoard(allTasks);
}
function onDragStart(e, id) {
  draggedId = id;
  e.dataTransfer.effectAllowed = 'move';
  setTimeout(function () { var c = document.getElementById('card-' + id); if (c) c.classList.add('dragging'); }, 0);
}
function onDragEnd() {
  if (draggedId) { var c = document.getElementById('card-' + draggedId); if (c) c.classList.remove('dragging'); }
}
function onDragOver(e)  { e.preventDefault(); e.currentTarget.classList.add('drag-over'); }
function onDragLeave(e) { e.currentTarget.classList.remove('drag-over'); }
function onDrop(e, newStatus) {
  e.preventDefault();
  e.currentTarget.classList.remove('drag-over');
  if (!draggedId) return;
  var task = allTasks.find(function (t) { return t.ID === draggedId; });
  if (!task || task.Status === newStatus) return;
  task.Status = newStatus;
  renderBoard(allTasks);
  google.script.run.withFailureHandler(function (err) { console.error('Status update failed:', err); })
    .updateTaskStatus(draggedId, newStatus, getActor());
  draggedId = null;
}

// ── ADD TASK MODAL ────────────────────────────────────────────
function openAddModal() {
  ['f-title','f-due','f-words','f-notes'].forEach(function (id) { var el = document.getElementById(id); if (el) el.value = ''; });
  var fPri = document.getElementById('f-priority'); if (fPri) fPri.value = 'Medium';
  var fOwn = document.getElementById('f-owner');    if (fOwn) fOwn.innerHTML = buildOwnerOptions('Unassigned');
  var fSec = document.getElementById('f-section');  if (fSec) fSec.innerHTML = buildSectionOptions('');
  var tb   = document.getElementById('f-notes-toolbar'); if (tb) tb.innerHTML = mdToolbar('f-notes');
  document.getElementById('addModal').classList.add('open');
}
function closeModal() { document.getElementById('addModal').classList.remove('open'); }
function saveTask() {
  var task = {
    Title:      (document.getElementById('f-title')    || {}).value || '',
    Section:    (document.getElementById('f-section')  || {}).value || '',
    Owner:      (document.getElementById('f-owner')    || {}).value || 'Unassigned',
    Priority:   (document.getElementById('f-priority') || {}).value || 'Medium',
    DueDate:    (document.getElementById('f-due')      || {}).value || '',
    WordTarget: (document.getElementById('f-words')    || {}).value || '',
    Notes:      (document.getElementById('f-notes')    || {}).value || '',
  };
  if (!task.Title.trim()) return;
  closeModal();
  google.script.run.withSuccessHandler(loadTasks)
    .withFailureHandler(function (e) { alert('Add task failed: ' + e.message); })
    .addTask(task, getActor());
}

// ── EDIT TASK MODAL ───────────────────────────────────────────
function openEditModal(e, id) {
  if (e) e.stopPropagation();
  var task = allTasks.find(function (t) { return t.ID === id; });
  if (!task) return;

  // Populate from live task data first
  document.getElementById('e-task-id').value = id;
  document.getElementById('e-title').value   = task.Title      || '';
  document.getElementById('e-due').value     = task.DueDate    || '';
  document.getElementById('e-words').value   = task.WordTarget || '';
  var eSec = document.getElementById('e-section');  if (eSec) eSec.innerHTML = buildSectionOptions(task.Section);
  var eOwn = document.getElementById('e-owner');    if (eOwn) eOwn.innerHTML = buildOwnerOptions(task.Owner);
  var ePri = document.getElementById('e-priority');
  if (ePri) ePri.innerHTML = ['High','Medium','Low'].map(function (p) {
    return '<option' + (p === task.Priority ? ' selected' : '') + '>' + p + '</option>';
  }).join('');
  var eNotes = document.getElementById('e-notes');
  if (eNotes) eNotes.value = task.Notes || '';
  var eTb = document.getElementById('e-notes-toolbar');
  if (eTb) eTb.innerHTML = mdToolbar('e-notes');

  // Hide draft banner initially
  var banner = document.getElementById('draft-banner');
  if (banner) banner.style.display = 'none';

  // Open modal immediately so user sees it while draft check runs
  document.getElementById('editTaskModal').classList.add('open');

  // Check server for an unexpired draft for this task
  google.script.run
    .withSuccessHandler(function (draft) {
      if (!draft) return;
      applyDraftFields(draft);
      if (banner) banner.style.display = 'flex';
    })
    .withFailureHandler(function () { /* no draft - fail silently */ })
    .getDraft(id);
}

function closeEditModal() {
  document.getElementById('editTaskModal').classList.remove('open');
  var banner = document.getElementById('draft-banner');
  if (banner) banner.style.display = 'none';
}
function saveEditModal() {
  var id = document.getElementById('e-task-id').value;
  if (!id) return;
  var btn = document.getElementById('e-save-btn');
  if (btn) { btn.disabled = true; btn.textContent = 'Saving...'; }
  var fields = {
    Title:      document.getElementById('e-title').value,
    Section:    document.getElementById('e-section').value,
    Owner:      document.getElementById('e-owner').value || 'Unassigned',
    DueDate:    document.getElementById('e-due').value,
    Priority:   document.getElementById('e-priority').value,
    WordTarget: document.getElementById('e-words').value,
    Notes:      document.getElementById('e-notes').value,
  };
  var task = allTasks.find(function (t) { return t.ID === id; });
  if (task) Object.assign(task, fields);
  var keys = Object.keys(fields); var pending = keys.length; var actor = getActor();
  // Clear draft on save - fire and forget
  google.script.run.clearDraft(id);
  function done() {
    if (--pending === 0) {
      if (btn) { btn.disabled = false; btn.textContent = 'Save changes'; }
      closeEditModal(); renderBoard(allTasks);
    }
  }
  keys.forEach(function (field) {
    google.script.run.withSuccessHandler(done)
      .withFailureHandler(function (err) { console.error(err); done(); })
      .updateTaskField(id, field, fields[field], actor);
  });
}

// ── VIEW NOTE MODAL ───────────────────────────────────────────
function openViewNoteModal(e, id) {
  e.stopPropagation();
  var task = allTasks.find(function (t) { return t.ID === id; });
  if (!task || !task.Notes) return;
  var vt = document.getElementById('vn-title');   if (vt) vt.textContent = task.Title;
  var vc = document.getElementById('vn-content'); if (vc) vc.innerHTML = parseMarkdown(task.Notes);
  var vb = document.getElementById('vn-btns');
  if (vb) vb.innerHTML =
    '<button class="btn-cancel" onclick="closeViewNoteModal()">Close</button>' +
    '<button class="btn-save"   onclick="switchToEditMode(\'' + id + '\')">Edit task</button>';
  document.getElementById('viewNoteModal').classList.add('open');
}
function closeViewNoteModal() { document.getElementById('viewNoteModal').classList.remove('open'); }
function switchToEditMode(id) { closeViewNoteModal(); setTimeout(function () { openEditModal(null, id); }, 60); }

// ── MEMBERS ───────────────────────────────────────────────────
function loadMembers(callback) {
  google.script.run
    .withSuccessHandler(function (members) {
      if (!members || members.error) { if (callback) callback(); return; }
      memberMap = {};
      members.forEach(function (m) { memberMap[String(m.initials).toUpperCase()] = m.name; });
      renderMembersTable(members);
      populateOwnerDropdowns();
      if (callback) callback();
    })
    .withFailureHandler(function () { if (callback) callback(); })
    .getMembers();
}
function renderMembersTable(members) {
  var tbody = document.getElementById('members-body');
  if (!tbody) return;
  if (!members || members.length === 0) {
    tbody.innerHTML = '<tr><td colspan="3" style="color:var(--text3);font-family:\'DM Mono\',monospace;font-size:12px;padding:12px 10px">No members yet</td></tr>';
    return;
  }
  tbody.innerHTML = members.map(function (m) {
    return '<tr>' +
      '<td style="font-family:\'DM Mono\',monospace;font-size:12px;color:var(--text2)">' + escHtml(m.initials) + '</td>' +
      '<td style="font-size:13px;color:var(--text)">' + escHtml(m.name) + '</td>' +
      '<td><button class="btn-del" onclick="removeMember(\'' + m.initials.replace(/'/g,"\\'") + '\')" title="Remove">&#x2715;</button></td>' +
    '</tr>';
  }).join('');
}
function addMember() {
  var initials = (document.getElementById('new-initials').value || '').trim().toUpperCase();
  var name     = (document.getElementById('new-name').value || '').trim();
  if (!initials || !name) return;
  google.script.run.withSuccessHandler(function () {
    document.getElementById('new-initials').value = '';
    document.getElementById('new-name').value     = '';
    loadMembers();
  }).saveMember(initials, name, getActor());
}
function removeMember(initials) {
  if (!confirm('Remove member ' + initials + ' from the board?')) return;
  google.script.run.withSuccessHandler(function () { loadMembers(); }).deleteMember(initials, getActor());
}
function buildOwnerOptions(selected) {
  return ['Unassigned'].concat(Object.values(memberMap)).map(function (n) {
    return '<option' + (n === selected ? ' selected' : '') + '>' + n + '</option>';
  }).join('');
}
function populateOwnerDropdowns() {
  var opts = buildOwnerOptions('Unassigned');
  ['f-owner'].forEach(function (id) { var el = document.getElementById(id); if (el) el.innerHTML = opts; });
  buildFilterButtons();
}
function buildFilterButtons() {
  var container = document.getElementById('filter-btns');
  if (!container) return;
  var members = Object.values(memberMap);
  container.innerHTML = ['<button class="filter-btn active" onclick="setFilter(\'all\',this)">All</button>']
    .concat(members.map(function (n) {
      return '<button class="filter-btn" onclick="setFilter(\'' + n.replace(/'/g,"\\'") + '\',this)">' + n + '</button>';
    }))
    .concat([
      '<button class="filter-btn" onclick="setFilter(\'Unassigned\',this)">Unassigned</button>',
      '<button class="filter-btn" onclick="setFilter(\'High\',this)">High priority</button>',
    ]).join('');
}
function updateProgress() {
  var total = allTasks.length;
  var done  = allTasks.filter(function (t) { return t.Status === 'Done'; }).length;
  var pct   = total === 0 ? 0 : Math.round((done / total) * 100);
  var fill  = document.getElementById('progress-fill');
  var pctEl = document.getElementById('progress-pct');
  var cnt   = document.getElementById('progress-counts');
  if (fill)  fill.style.width  = pct + '%';
  if (pctEl) pctEl.textContent = pct + '%';
  if (cnt)   cnt.textContent   = done + ' / ' + total + ' done';
}


// ── CARD TOOLTIP (position:fixed, escapes overflow clip) ──────
var _tooltipEl = null;
function showCardTooltip(e, taskId) {
  hideCardTooltip();
  var task = allTasks.find(function (t) { return t.ID === taskId; });
  if (!task || !task.Notes) return;
  var el = document.createElement('div');
  el.className = 'card-notes-tooltip visible';
  el.innerHTML = parseMarkdown(task.Notes);
  document.body.appendChild(el);
  _tooltipEl = el;
  positionTooltip(e, el);
}
function positionTooltip(e, el) {
  var rect  = e.currentTarget.getBoundingClientRect();
  var gap   = 10;
  var tw    = el.offsetWidth  || 260;
  var th    = el.offsetHeight || 200;
  var left  = rect.right + gap;
  var top   = rect.top;
  // Flip left if overflows right edge
  if (left + tw > window.innerWidth - 8) left = rect.left - tw - gap;
  // Clamp vertical
  if (top + th > window.innerHeight - 8) top = window.innerHeight - th - 8;
  if (top < 8) top = 8;
  el.style.left = left + 'px';
  el.style.top  = top  + 'px';
}
function hideCardTooltip() {
  if (_tooltipEl) { _tooltipEl.remove(); _tooltipEl = null; }
}

// ── DRAFT AUTOSAVE ────────────────────────────────────────────
function getDraftFields() {
  return JSON.stringify({
    Title:      (document.getElementById('e-title')    || {}).value || '',
    Section:    (document.getElementById('e-section')  || {}).value || '',
    Owner:      (document.getElementById('e-owner')    || {}).value || '',
    Priority:   (document.getElementById('e-priority') || {}).value || '',
    DueDate:    (document.getElementById('e-due')      || {}).value || '',
    WordTarget: (document.getElementById('e-words')    || {}).value || '',
    Notes:      (document.getElementById('e-notes')    || {}).value || '',
  });
}

function applyDraftFields(draft) {
  try {
    var d = JSON.parse(draft);
    if (d.Title      !== undefined) document.getElementById('e-title').value    = d.Title;
    if (d.Section    !== undefined) { var es = document.getElementById('e-section');   if (es) es.innerHTML  = buildSectionOptions(d.Section); }
    if (d.Owner      !== undefined) { var eo = document.getElementById('e-owner');     if (eo) eo.innerHTML  = buildOwnerOptions(d.Owner); }
    if (d.Priority   !== undefined) { var ep = document.getElementById('e-priority');  if (ep) { for (var i = 0; i < ep.options.length; i++) ep.options[i].selected = ep.options[i].value === d.Priority; } }
    if (d.DueDate    !== undefined) document.getElementById('e-due').value      = d.DueDate;
    if (d.WordTarget !== undefined) document.getElementById('e-words').value    = d.WordTarget;
    if (d.Notes      !== undefined) { document.getElementById('e-notes').value  = d.Notes; }
  } catch (err) { console.error('Draft parse error', err); }
}

function saveDraftAndClose() {
  var id = (document.getElementById('e-task-id') || {}).value;
  if (!id) { document.getElementById('editTaskModal').classList.remove('open'); return; }
  google.script.run
    .withSuccessHandler(function () {
      document.getElementById('editTaskModal').classList.remove('open');
    })
    .withFailureHandler(function () {
      document.getElementById('editTaskModal').classList.remove('open');
    })
    .saveDraft(id, getDraftFields());
}

function discardDraft() {
  var id = (document.getElementById('e-task-id') || {}).value;
  if (!id) return;
  var banner = document.getElementById('draft-banner');
  if (banner) banner.style.display = 'none';
  google.script.run.clearDraft(id);
  // Repopulate from live task data
  var task = allTasks.find(function (t) { return t.ID === id; });
  if (task) {
    document.getElementById('e-title').value  = task.Title   || '';
    document.getElementById('e-due').value    = task.DueDate  || '';
    document.getElementById('e-words').value  = task.WordTarget || '';
    document.getElementById('e-section').innerHTML  = buildSectionOptions(task.Section);
    document.getElementById('e-owner').innerHTML    = buildOwnerOptions(task.Owner);
    var ep = document.getElementById('e-priority');
    if (ep) for (var i = 0; i < ep.options.length; i++) ep.options[i].selected = ep.options[i].value === task.Priority;
    document.getElementById('e-notes').value  = task.Notes || '';
  }
}

// ── SUBMISSIONS ───────────────────────────────────────────────
function renderDocs(docs) {
  var container = document.getElementById('docs-container');
  if (!container) return;
  if (!docs || docs.error) { container.innerHTML = '<div class="docs-empty">Error loading files: ' + (docs && docs.error || 'unknown') + '</div>'; return; }
  if (docs.length === 0)   { container.innerHTML = '<div class="docs-empty">No files uploaded yet.</div>'; return; }
  var iconFor = function (t) {
    if (t && t.includes('pdf'))          return { label:'PDF',  cls:'' };
    if (t && t.includes('document'))     return { label:'DOC',  cls:'gdoc' };
    if (t && t.includes('spreadsheet'))  return { label:'XLS',  cls:'gsheet' };
    if (t && t.includes('presentation')) return { label:'PPT',  cls:'' };
    return { label:'FILE', cls:'' };
  };
  container.innerHTML = '<div class="docs-grid">' + docs.map(function (doc) {
    var icon     = iconFor(doc.type);
    var noExt    = doc.name.replace(/\.[^.]+$/, '');
    var parts    = noExt.split('_');
    var initials = parts[parts.length - 1].toUpperCase();
    var owner    = memberMap[initials] || null;
    var tag      = owner ? 'doc_' + initials : '';
    return '<a class="doc-card" href="' + doc.url + '" target="_blank">' +
      (owner ? '<div class="doc-tooltip">' + escHtml(owner) + '</div>' : '') +
      '<div class="doc-icon ' + icon.cls + '">' + icon.label + '</div>' +
      '<div class="doc-info">' +
        '<div class="doc-name">' + escHtml(doc.name) + '</div>' +
        '<div class="doc-meta" style="display:flex;align-items:center;gap:6px;">' +
          doc.size + ' &middot; ' + doc.modified +
          (owner ? ' &middot; ' + escHtml(owner) : '') +
          (tag ? ' <span onclick="event.preventDefault();navigator.clipboard.writeText(\'' + tag + '\');var t=this;t.textContent=\'Copied!\';setTimeout(function(){t.textContent=\'' + tag + '\'},1500);" style="padding:2px 6px;background:var(--surface2);border:1px solid var(--border2);border-radius:4px;font-family:\'DM Mono\',monospace;font-size:10px;color:var(--accent);cursor:pointer;" title="Click to copy tag">' + tag + '</span>' : '') +
        '</div>' +
      '</div></a>';
  }).join('') + '</div>';
}
function loadDocs() {
  var c = document.getElementById('docs-container');
  if (c) c.innerHTML = '<div class="docs-loading"><div class="spinner"></div> Loading...</div>';
  google.script.run.withSuccessHandler(renderDocs)
    .withFailureHandler(function (e) {
      var c2 = document.getElementById('docs-container');
      if (c2) c2.innerHTML = '<div class="docs-empty">Failed: ' + e.message + '</div>';
    }).getDocuments();
}
function syncReviewCards() {
  var btn = document.getElementById('sync-btn');
  if (!btn) return;
  btn.innerHTML = '&#x27F3; Scanning...';
  btn.style.opacity = '.6'; btn.style.pointerEvents = 'none';
  google.script.run
    .withSuccessHandler(function (result) {
      btn.style.opacity = '1'; btn.style.pointerEvents = 'auto';
      if (result && result.error) { btn.innerHTML = '&#x2715; Error'; setTimeout(function () { btn.innerHTML = '&#x27F3; Sync review tasks'; }, 3000); return; }
      btn.innerHTML = result && result.created > 0 ? '&#x2713; Added ' + result.created : '&#x2713; Up to date';
      if (result && result.created > 0) loadTasks();
      setTimeout(function () { btn.innerHTML = '&#x27F3; Sync review tasks'; }, 3000);
    })
    .withFailureHandler(function () {
      btn.innerHTML = '&#x2715; Failed'; btn.style.opacity = '1'; btn.style.pointerEvents = 'auto';
      setTimeout(function () { btn.innerHTML = '&#x27F3; Sync review tasks'; }, 3000);
    }).syncReviewCards(getActor());
}
function seedSectionTasks() {
  var btn = document.getElementById('seed-btn');
  if (!btn) return;
  btn.textContent = 'Seeding...'; btn.style.opacity = '.6'; btn.style.pointerEvents = 'none';
  google.script.run
    .withSuccessHandler(function (result) {
      btn.style.opacity = '1'; btn.style.pointerEvents = 'auto';
      if (result && result.error) { btn.textContent = 'Error'; setTimeout(function () { btn.textContent = 'Seed section tasks'; }, 3000); return; }
      btn.innerHTML = result && result.created > 0 ? '&#x2713; Added ' + result.created : '&#x2713; All exist';
      if (result && result.created > 0) loadTasks();
      setTimeout(function () { btn.textContent = 'Seed section tasks'; }, 3000);
    })
    .withFailureHandler(function () {
      btn.style.opacity = '1'; btn.style.pointerEvents = 'auto'; btn.textContent = 'Error';
      setTimeout(function () { btn.textContent = 'Seed section tasks'; }, 3000);
    }).seedSectionTasks(getActor());
}

// ── MEETING NOTES ─────────────────────────────────────────────
function renderNotes(notes) {
  var c = document.getElementById('notes-container');
  if (!c) return;
  if (!notes || notes.error) { c.innerHTML = '<div class="notes-empty">Error loading notes</div>'; return; }
  if (notes.length === 0)    { c.innerHTML = '<div class="notes-empty">No meeting notes yet.</div>'; return; }
  c.innerHTML = notes.map(function (n) {
    var safeId = String(n.id).replace(/'/g,"\'");
    return '<div class="note-entry">' +
      '<div class="note-header">' +
        '<div>' +
          '<div class="note-meta">' + escHtml(n.date || '') + (n.author && n.author !== 'Unassigned' ? ' &middot; ' + escHtml(n.author) : '') + '</div>' +
          '<div class="note-title-text">' + escHtml(n.title || '') + '</div>' +
        '</div>' +
        '<div style="display:flex;align-items:center;gap:6px;">' +
          '<button class="note-del" onclick="emailNote(\'' + safeId + '\',this)" title="Email to group" ' +
            'style="font-size:11px;padding:3px 7px;border-radius:4px;border:1px solid var(--border2);background:var(--surface2);color:var(--text2);font-family:'DM Mono',monospace;cursor:pointer;">' +
            '&#x2709; Email' +
          '</button>' +
          '<button class="note-del" onclick="deleteNote(\'' + safeId + '\')" title="Delete">&#x2715;</button>' +
        '</div>' +
      '</div>' +
      '<div class="note-body">' + parseMarkdown(n.body || '') + '</div>' +
    '</div>';
  }).join('');
}

function emailNote(noteId, btn) {
  var actor = getActor();
  var orig  = btn.textContent;
  btn.disabled = true; btn.textContent = 'Sending...';
  google.script.run
    .withSuccessHandler(function (result) {
      btn.disabled = false;
      if (result && result.error) {
        btn.textContent = orig;
        alert('Email failed: ' + result.error);
        return;
      }
      btn.textContent = '&#x2713; Sent to ' + (result.sent || 0);
      setTimeout(function () { btn.textContent = orig; }, 3000);
    })
    .withFailureHandler(function (e) {
      btn.disabled = false; btn.textContent = orig;
      alert('Email failed: ' + e.message);
    })
    .emailNoteToGroup(noteId, actor);
}
function loadNotes() {
  var c = document.getElementById('notes-container');
  if (!c) return;
  c.innerHTML = '<div class="docs-loading"><div class="spinner"></div> Loading notes...</div>';
  google.script.run.withSuccessHandler(renderNotes)
    .withFailureHandler(function (e) { c.innerHTML = '<div class="notes-empty">Failed: ' + e.message + '</div>'; })
    .getNotes();
}
function openNoteModal() {
  var nTitle = document.getElementById('n-title'); if (nTitle) nTitle.value = '';
  var nDate  = document.getElementById('n-date');  if (nDate)  nDate.value  = new Date().toLocaleDateString('en-AU', {day:'numeric',month:'short',year:'numeric'});
  var nBody  = document.getElementById('n-body');  if (nBody)  nBody.value  = '';
  var nAuth  = document.getElementById('n-author');
  if (nAuth) {
    nAuth.innerHTML = ['Unassigned'].concat(Object.values(memberMap)).map(function (n) { return '<option>' + n + '</option>'; }).join('');
    var actor = getActor();
    for (var i = 0; i < nAuth.options.length; i++) {
      if (nAuth.options[i].value === actor) { nAuth.selectedIndex = i; break; }
    }
  }
  var tb = document.getElementById('n-body-toolbar'); if (tb) tb.innerHTML = mdToolbar('n-body');
  document.getElementById('noteModal').classList.add('open');
}
function closeNoteModal() { document.getElementById('noteModal').classList.remove('open'); }
function saveNote() {
  var title  = (document.getElementById('n-title')  || {}).value || '';
  var date   = (document.getElementById('n-date')   || {}).value || '';
  var body   = (document.getElementById('n-body')   || {}).value || '';
  var author = (document.getElementById('n-author') || {}).value || 'Unassigned';
  if (!title.trim()) return;
  closeNoteModal();
  google.script.run.withSuccessHandler(loadNotes).addNote(title, date, body, author, getActor());
}
function deleteNote(id) {
  if (!confirm('Delete this meeting note? This cannot be undone.')) return;
  google.script.run.withSuccessHandler(loadNotes).deleteNote(id, getActor());
}

// ── GOOGLE MEET SCHEDULER ─────────────────────────────────────
function generateMeetLink() {
  var title    = (document.getElementById('meet-title') || {}).value || 'Group Sync';
  var dateVal  = (document.getElementById('meet-date')  || {}).value;
  var startVal = (document.getElementById('meet-start') || {}).value;
  var endVal   = (document.getElementById('meet-end')   || {}).value;
  var tzVal    = (document.getElementById('meet-tz')    || {}).value || 'Australia/Brisbane';
  if (!dateVal || !startVal || !endVal) { alert('Please select a date, start time, and end time.'); return; }
  var fmt = function (d, t) { return d.replace(/-/g,'') + 'T' + t.replace(/:/g,'') + '00'; };
  var url = 'https://calendar.google.com/calendar/render?action=TEMPLATE' +
    '&text=' + encodeURIComponent(title) +
    '&dates=' + fmt(dateVal, startVal) + '/' + fmt(dateVal, endVal) +
    '&ctz='   + encodeURIComponent(tzVal) +
    '&details=' + encodeURIComponent('Created by Welsford_KanBan task board.');
  window.open(url, '_blank');
}

// ── REPORT TAB ────────────────────────────────────────────────
function loadReportSections() {
  var list = document.getElementById('at3-section-list');
  if (list) list.innerHTML = '<div class="docs-loading"><div class="spinner"></div> Loading sections...</div>';
  google.script.run
    .withSuccessHandler(function (sections) {
      liveSections = sections || [];
      renderReportSections(sections);
      // Fire live word count as second pass
      refreshWordCounts();
    })
    .withFailureHandler(function (e) {
      if (list) list.innerHTML = '<div class="docs-empty">Failed to load sections: ' + e.message + '</div>';
    })
    .getSectionDocuments();
}

// Strip any hex colour codes or non-alphanumeric chars that
// may appear in sec.num if config fields were accidentally swapped.
function sanitiseSectionNum(num) {
  if (!num) return '';
  var s = String(num).trim();
  // If it looks like a CSS colour (#xxxxxx or #xxx) drop it entirely
  if (/^#[0-9a-fA-F]{3,8}$/.test(s)) return '';
  // Keep only digits, letters, hyphens, underscores
  return s.replace(/[^a-zA-Z0-9\-_]/g, '');
}

function renderReportSections(sections) {
  var list = document.getElementById('at3-section-list');
  if (!list) return;
  if (!sections || sections.error) {
    list.innerHTML = '<div class="docs-empty">Could not load section documents. Check DOCUMENTS_FOLDER_ID in config.gs.</div>';
    return;
  }
  if (sections.length === 0) {
    list.innerHTML = '<div class="docs-empty">No Google Docs found in the documents folder.</div>';
    return;
  }
  list.innerHTML = sections.map(function (sec) {
    var key      = sanitiseSectionNum(sec.num) || sec.name;
    var wc       = sectionWordCounts[key] || 0;
    var floor    = sec.target > 0 ? sec.target : 0;
    var ceiling  = sectionCeilings[key] || 0;
    var floorStr = floor > 0 ? '~' + floor + 'w floor' : 'no limit';
    var safeKey  = escHtml(key);
    return '<div class="section-item">' +
      (sec.num ? '<span class="section-num">' + sec.num + '</span>' : '') +
      '<span class="section-name">'   + escHtml(sec.name) + '</span>' +
      '<span class="section-target">' + floorStr + '</span>' +
      '<div class="section-wc" style="flex-direction:column;align-items:flex-start;gap:3px;">' +
        '<div style="display:flex;align-items:center;gap:4px;">' +
          '<span class="wc-value" id="wc-val-' + safeKey + '">' +
            (wc === -1 ? '<span style="color:var(--pri-high);font-size:10px">read error</span>' : wc) +
          '</span>' +
          '<span class="wc-label-sm">words</span>' +
        '</div>' +
        '<div class="wc-ceiling-row">' +
          '<span class="wc-ceiling-label">ceiling:</span>' +
          '<input class="wc-ceiling-input" type="number" min="0"' +
            ' id="ceil-' + safeKey + '"' +
            ' value="' + (ceiling || '') + '"' +
            ' placeholder="optional"' +
            ' onchange="updateCeiling('' + key + '',this.value)">' +
          '<span class="wc-ceiling-label">w</span>' +
        '</div>' +
      '</div>' +
      '<a class="open-doc-btn" href="' + sec.docUrl + '" target="_blank" style="text-decoration:none">Open &#x2197;</a>' +
    '</div>';
  }).join('');
  updateAt3Progress(sections);
}

function updateCeiling(key, val) {
  sectionCeilings[key] = parseInt(val) || 0;
  updateAt3Progress(liveSections);
}

function refreshWordCounts() {
  var btn = document.getElementById('wc-refresh-btn');
  if (btn) { btn.innerHTML = '&#x27F3; Counting...'; btn.disabled = true; }
  google.script.run
    .withSuccessHandler(function (counts) {
      if (!counts || counts.error) {
        if (btn) { btn.innerHTML = '&#x2715; Error'; btn.disabled = false; setTimeout(function () { btn.innerHTML = '&#x27F3; Refresh word counts'; }, 3000); }
        return;
      }
      sectionWordCounts = counts;
      // Update displayed values in-place without re-rendering the whole list
      Object.keys(counts).forEach(function (key) {
        var el = document.getElementById('wc-val-' + key);
        if (el) {
          var wc = counts[key];
          el.innerHTML = wc === -1
            ? '<span style="color:var(--pri-high);font-size:10px">read error</span>'
            : String(wc);
        }
      });
      updateAt3Progress(liveSections);
      if (btn) { btn.innerHTML = '&#x2713; Updated'; btn.disabled = false; setTimeout(function () { btn.innerHTML = '&#x27F3; Refresh word counts'; }, 2500); }
    })
    .withFailureHandler(function (e) {
      if (btn) { btn.innerHTML = '&#x2715; Failed'; btn.disabled = false; setTimeout(function () { btn.innerHTML = '&#x27F3; Refresh word counts'; }, 3000); }
    })
    .getLiveWordCounts();
}

function updateAt3Progress(sectionsArg) {
  var validCounts = Object.keys(sectionWordCounts).reduce(function (acc, k) {
    if (sectionWordCounts[k] > 0) acc[k] = sectionWordCounts[k];
    return acc;
  }, {});
  var total  = Object.values(sectionWordCounts).reduce(function (a,b) { return a + (b > 0 ? b : 0); }, 0);
  var target = CLIENT_CONFIG.reportWordTarget || 0;
  var pct    = target > 0 ? Math.min(100, Math.round((total / target) * 100)) : 0;
  var fill   = document.getElementById('at3-fill');
  var tot    = document.getElementById('at3-total-wc');
  if (fill) fill.style.width = pct + '%';
  if (tot)  tot.textContent  = total + ' / ' + target + ' words';
  var bars    = document.getElementById('at3-section-bars');
  if (!bars) return;
  var secList = sectionsArg || liveSections || CLIENT_CONFIG.sections || [];
  bars.innerHTML = secList.filter(function (s) { return s.target > 0; }).map(function (sec) {
    var key     = sanitiseSectionNum(sec.num) || sec.name;
    var wc      = sectionWordCounts[key] > 0 ? sectionWordCounts[key] : 0;
    var floor   = sec.target;
    var ceiling = sectionCeilings[key] || 0;
    var p       = Math.min(100, Math.round((wc / floor) * 100));
    // Zone colouring: amber = between floor and ceiling, red = over ceiling
    var zoneCls = '';
    if (ceiling > 0 && wc > ceiling) {
      zoneCls = 'red';
    } else if (ceiling > 0 && wc > floor) {
      zoneCls = 'amber';
    }
    var pctLabel = wc + '/' + floor + (ceiling > 0 ? ' (ceil ' + ceiling + ')' : '');
    return '<div class="at3-bar-row">' +
      '<span class="at3-bar-name">' + escHtml(sec.name) + '</span>' +
      '<div class="at3-bar-track"><div class="at3-bar-fill ' + zoneCls + '" style="width:' + p + '%"></div></div>' +
      '<span class="at3-bar-pct' + (zoneCls === 'red' ? '" style="color:var(--pri-high)"' : zoneCls === 'amber' ? '" style="color:#c97d2a"' : '"') + '>' + pctLabel + '</span>' +
    '</div>';
  }).join('');
}

function compileReport() {
  var btn = document.getElementById('compile-btn');
  var log = document.getElementById('compile-log');
  if (btn) { btn.disabled = true; btn.innerHTML = '&#x27F3; Compiling...'; }
  if (log) { log.className = 'compile-log visible'; log.innerHTML = '<span class="log-info">Starting compile...</span>'; }
  google.script.run
    .withSuccessHandler(function (result) {
      if (btn) { btn.disabled = false; btn.textContent = 'Compile and export .docx'; }
      if (!log) return;
      if (result.error) { log.innerHTML += '<br><span class="log-error">Error: ' + result.error + '</span>'; return; }
      log.innerHTML += '<br><span class="log-success">&#x2713; ' + (result.sections || 0) + ' sections compiled</span>';
      if (result.url) log.innerHTML += '<br><span class="log-info"><a href="' + result.url + '" target="_blank" style="color:var(--accent)">Download compiled .docx &#x2197;</a></span>';
      if (result.warnings) result.warnings.forEach(function (w) { log.innerHTML += '<br><span class="log-error">&#x26A0; ' + w + '</span>'; });
    })
    .withFailureHandler(function (e) {
      if (btn) { btn.disabled = false; btn.textContent = 'Compile and export .docx'; }
      if (log) log.innerHTML += '<br><span class="log-error">Failed: ' + e.message + '</span>';
    }).compileReport(getActor());
}

// ── SOURCES ───────────────────────────────────────────────────
function loadSources() {
  google.script.run
    .withSuccessHandler(function (sources) {
      if (!sources || sources.error) {
        var el = document.getElementById('sources-container');
        if (el) el.innerHTML = '<div class="sources-empty">Error loading sources</div>';
        return;
      }
      allSources = sources;
      renderSources(sources);
    })
    .withFailureHandler(function (e) {
      var el = document.getElementById('sources-container');
      if (el) el.innerHTML = '<div class="sources-empty">Failed: ' + e.message + '</div>';
    }).getSources();
}

function renderSources(sources) {
  var container = document.getElementById('sources-container');
  if (!container) return;
  var filtered = srcFilter === 'all'     ? sources
    : srcFilter === 'journal' ? sources.filter(function (s) { return s.type === 'journal'; })
    : sources.filter(function (s) { return s.section === srcFilter; });
  var cnt = document.getElementById('src-count');
  var validCount   = filtered.filter(function (s) { return s.valid !== false; }).length;
  var invalidCount = filtered.filter(function (s) { return s.valid === false; }).length;
  if (cnt) cnt.textContent = validCount + ' valid' + (invalidCount > 0 ? ', ' + invalidCount + ' invalid' : '');
  if (filtered.length === 0) { container.innerHTML = '<div class="sources-empty">No sources found.</div>'; return; }

  var validSources   = filtered.filter(function (s) { return s.valid !== false; });
  var invalidSources = filtered.filter(function (s) { return s.valid === false; });

  function renderRow(s) {
    var validBadge = s.valid !== false
      ? '<span style="display:inline-block;padding:2px 7px;border-radius:4px;font-size:10px;font-family:\'DM Mono\',monospace;background:rgba(76,175,118,.15);color:#4caf76;border:1px solid rgba(76,175,118,.3)">valid</span>'
      : '<span style="display:inline-block;padding:2px 7px;border-radius:4px;font-size:10px;font-family:\'DM Mono\',monospace;background:rgba(224,90,90,.12);color:#e05a5a;border:1px solid rgba(224,90,90,.3)">invalid</span>';
    var toggleLabel = s.valid !== false ? 'Mark invalid' : 'Mark valid';
    var toggleFn    = 'toggleSourceValid(\'' + s.id + '\',' + (s.valid !== false ? 'false' : 'true') + ')';
    return '<tr>' +
      '<td style="max-width:240px">' +
        '<div class="src-title">' + escHtml(s.title || '') + '</div>' +
        '<div style="font-size:11px;color:var(--text3);font-family:\'DM Mono\',monospace;margin-top:2px">' + escHtml(s.authors || '') + '</div>' +
        (s.url ? '<a class="src-url" href="' + s.url + '" target="_blank">' + escHtml(s.url) + '</a>' : '') +
      '</td>' +
      '<td style="white-space:nowrap;font-family:\'DM Mono\',monospace;font-size:12px">' + escHtml(s.year || '') + '</td>' +
      '<td><span class="src-type-badge ' + (s.type||'') + '">' + escHtml(s.type || '') + '</span></td>' +
      '<td style="font-size:12px;font-family:\'DM Mono\',monospace;color:var(--text3)">' + escHtml(s.section || '') + '</td>' +
      '<td style="font-size:12px;color:var(--text2);max-width:180px">' + escHtml(s.notes || '') + '</td>' +
      '<td>' + validBadge + '</td>' +
      '<td style="white-space:nowrap">' +
        '<button class="src-del" onclick="' + toggleFn + '" title="' + toggleLabel + '" style="color:var(--text3);font-size:10px;padding:2px 5px">' + toggleLabel + '</button>' +
        '<button class="src-del" onclick="editSource(\'' + s.id + '\')" title="Edit" style="color:var(--text3)">&#x270E;</button>' +
        '<button class="src-del" onclick="deleteSource(\'' + s.id + '\')" title="Delete">&#x2715;</button>' +
      '</td>' +
    '</tr>';
  }

  var tableHead = '<table class="sources-table"><thead><tr>' +
    '<th>Title / Authors</th><th>Year</th><th>Type</th><th>Section</th><th>Notes</th><th>Status</th><th></th>' +
    '</tr></thead><tbody>';

  var html = tableHead + validSources.map(renderRow).join('');

  if (invalidSources.length > 0) {
    html += '<tr><td colspan="7" style="padding:8px 0"><hr style="border:none;border-top:1px solid var(--border2);margin:0"></td></tr>';
    html += invalidSources.map(renderRow).join('');
  }

  html += '</tbody></table>';
  container.innerHTML = html;
}

function toggleSourceValid(id, valid) {
  google.script.run
    .withSuccessHandler(loadSources)
    .withFailureHandler(function (e) { alert('Failed to update: ' + e.message); })
    .setSourceValid(id, valid, getActor());
}

function filterSources(f, btn) {
  srcFilter = f;
  document.querySelectorAll('.src-filter-btn').forEach(function (b) { b.classList.remove('active'); });
  if (btn) btn.classList.add('active');
  renderSources(allSources);
}
function openSourceModal() {
  document.getElementById('src-edit-id').value           = '';
  document.getElementById('src-modal-title').textContent  = 'Add source';
  document.getElementById('src-save-btn').textContent     = 'Add source';
  ['src-title','src-authors','src-year','src-url','src-notes'].forEach(function (id) {
    var el = document.getElementById(id); if (el) el.value = '';
  });
  document.getElementById('srcModal').classList.add('open');
}
function editSource(id) {
  var s = allSources.find(function (src) { return String(src.id) === String(id); });
  if (!s) return;
  document.getElementById('src-edit-id').value           = id;
  document.getElementById('src-modal-title').textContent  = 'Edit source';
  document.getElementById('src-save-btn').textContent     = 'Save changes';
  document.getElementById('src-title').value              = s.title   || '';
  document.getElementById('src-authors').value            = s.authors || '';
  document.getElementById('src-year').value               = s.year    || '';
  document.getElementById('src-url').value                = s.url     || '';
  document.getElementById('src-notes').value              = s.notes   || '';
  var typeEl = document.getElementById('src-type');
  if (typeEl) for (var i = 0; i < typeEl.options.length; i++) {
    if (typeEl.options[i].value === s.type) { typeEl.selectedIndex = i; break; }
  }
  var secEl = document.getElementById('src-section-select');
  if (secEl) for (var j = 0; j < secEl.options.length; j++) {
    if (secEl.options[j].value === s.section || secEl.options[j].text === s.section) { secEl.selectedIndex = j; break; }
  }
  document.getElementById('srcModal').classList.add('open');
}
function closeSrcModal() { document.getElementById('srcModal').classList.remove('open'); }
function saveSource() {
  var editId = document.getElementById('src-edit-id').value;
  var source = {
    title:   (document.getElementById('src-title')          || {}).value || '',
    authors: (document.getElementById('src-authors')        || {}).value || '',
    year:    (document.getElementById('src-year')           || {}).value || '',
    type:    (document.getElementById('src-type')           || {}).value || '',
    url:     (document.getElementById('src-url')            || {}).value || '',
    section: (document.getElementById('src-section-select') || {}).value || '',
    notes:   (document.getElementById('src-notes')          || {}).value || '',
  };
  if (!source.title.trim()) return;
  closeSrcModal();
  if (editId) {
    google.script.run.withSuccessHandler(loadSources)
      .withFailureHandler(function (e) { alert('Update failed: ' + e.message); })
      .updateSource(editId, source, getActor());
  } else {
    google.script.run.withSuccessHandler(loadSources)
      .withFailureHandler(function (e) { alert('Add failed: ' + e.message); })
      .addSource(source, getActor());
  }
}
function deleteSource(id) {
  if (!confirm('Delete this source? This cannot be undone.')) return;
  google.script.run.withSuccessHandler(loadSources)
    .withFailureHandler(function (e) { alert('Delete failed: ' + e.message); })
    .deleteSource(id, getActor());
}
function quickAddSource() {
  var input = document.getElementById('quick-url-input');
  var btn   = document.getElementById('quick-fetch-btn');
  if (!input || !btn) return;
  var val = input.value.trim();
  if (!val) return;
  btn.textContent = 'Fetching...'; btn.style.pointerEvents = 'none'; btn.style.opacity = '.6';
  google.script.run
    .withSuccessHandler(function (meta) {
      btn.textContent = 'Fetch metadata'; btn.style.pointerEvents = 'auto'; btn.style.opacity = '1';
      if (meta.error) { alert('Could not fetch: ' + meta.error); return; }
      document.getElementById('src-edit-id').value           = '';
      document.getElementById('src-modal-title').textContent  = 'Add source';
      document.getElementById('src-save-btn').textContent     = 'Add source';
      document.getElementById('src-title').value              = meta.title   || '';
      document.getElementById('src-authors').value            = meta.authors || '';
      document.getElementById('src-year').value               = meta.year    || '';
      document.getElementById('src-url').value                = meta.url     || val;
      document.getElementById('src-notes').value              = meta.journal ? 'Published in: ' + meta.journal : '';
      var typeEl = document.getElementById('src-type');
      if (typeEl && meta.type) for (var i = 0; i < typeEl.options.length; i++) {
        if (typeEl.options[i].value === meta.type) { typeEl.selectedIndex = i; break; }
      }
      input.value = '';
      document.getElementById('srcModal').classList.add('open');
    })
    .withFailureHandler(function (err) {
      btn.textContent = 'Fetch metadata'; btn.style.pointerEvents = 'auto'; btn.style.opacity = '1';
      alert('Fetch failed: ' + err.message);
    }).fetchSourceMetadata(val);
}
function pushReferencesToDoc() {
  var btn    = document.getElementById('push-refs-btn');
  var format = (document.getElementById('citation-format') || {}).value || 'ieee';
  var validCount = allSources.filter(function (s) { return s.valid !== false; }).length;
  if (validCount === 0) { alert('No valid sources to push. Mark at least one source as valid first.'); return; }
  var labels = { ieee:'IEEE', apa:'APA 7th', harvard:'Harvard', chicago:'Chicago', plain:'Plain text' };
  if (!confirm('Push ' + validCount + ' valid source' + (validCount !== 1 ? 's' : '') + ' to the References doc in ' + (labels[format]||format) + ' format?\n\nThis will replace the entire doc content. Invalid sources will be excluded.')) return;
  if (btn) { btn.disabled = true; btn.textContent = 'Pushing...'; }
  google.script.run
    .withSuccessHandler(function (result) {
      if (btn) { btn.disabled = false; btn.textContent = 'Push to References doc'; }
      if (result.error) { alert('Error: ' + result.error); return; }
      var msg = result.count + ' source' + (result.count !== 1 ? 's' : '') + ' written to ' + result.docName;
      if (result.total && result.total !== result.count) msg += ' (' + (result.total - result.count) + ' invalid skipped)';
      if (btn) { btn.textContent = msg; setTimeout(function () { btn.textContent = 'Push to References doc'; }, 4000); }
      if (confirm(msg + '\n\nOpen the doc now?')) window.open(result.url, '_blank');
    })
    .withFailureHandler(function (err) {
      if (btn) { btn.disabled = false; btn.textContent = 'Push to References doc'; }
      alert('Failed: ' + err.message);
    }).pushReferencesToDoc(format, getActor());
}

// ── REFERENCE SCANNER ─────────────────────────────────────────
// Parses a reference string attempting to extract structured fields.
// Handles IEEE [N] format, APA, Harvard, and plain text.
function parseRefString(raw) {
  var title = '', authors = '', year = '', url = '';

  // Extract URL
  var urlMatch = raw.match(/https?:\/\/[^\s]+/);
  if (urlMatch) { url = urlMatch[0].replace(/[.,)>]+$/, ''); }

  // IEEE: [N] Authors, "Title," Year.
  var ieeeMatch = raw.match(/^\[?\d+\]?\s+(.+?),\s+"(.+?)(?:,"|,")\s*(\d{4})/);
  if (ieeeMatch) {
    authors = ieeeMatch[1].trim();
    title   = ieeeMatch[2].trim();
    year    = ieeeMatch[3];
    return { title: title, authors: authors, year: year, url: url, raw: raw };
  }

  // Year extraction fallback
  var yearMatch = raw.match(/\b(19|20)\d{2}\b/);
  if (yearMatch) year = yearMatch[0];

  // Attempt to split on year for APA/Harvard style
  if (year) {
    var parts = raw.split(year);
    if (parts.length >= 2) {
      authors = parts[0].replace(/\(?\s*$/, '').trim();
      title   = parts[1].replace(/^\)?\.?\s*/, '').split('.')[0].trim();
    }
  }

  // Strip leading [N] from authors
  authors = authors.replace(/^\[?\d+\]?\s*/, '').trim();

  // Fallback: use first sentence as title
  if (!title) title = raw.split('.')[0].replace(/^\[?\d+\]?\s*/, '').trim();

  return { title: title || raw.substring(0, 80), authors: authors, year: year, url: url, raw: raw };
}

function triggerScanner() {
  var input  = document.getElementById('scan-doc-id');
  var result = document.getElementById('scan-results');
  if (!input || !result) return;
  var docId = input.value.trim();
  if (!docId) { result.innerHTML = '<span style="color:var(--pri-high)">Enter a Google Doc ID or doc_XX tag.</span>'; return; }
  result.innerHTML = '<span style="color:var(--text3)">Scanning...</span>';
  google.script.run
    .withSuccessHandler(function (resp) {
      if (!resp.success && resp.docsOpened === 0) {
        result.innerHTML = '<span style="color:var(--pri-high)">&#x2715; ' + escHtml(resp.message) + '</span>';
        return;
      }
      var diag = '<div style="font-size:11px;color:var(--text3);font-family:\'DM Mono\',monospace;margin-bottom:8px;border-bottom:1px solid var(--border);padding-bottom:6px">' +
        'Docs opened: ' + resp.docsOpened +
        ' &middot; Heading found: ' + (resp.headingFound ? '<span style="color:var(--pri-low)">yes</span>' : '<span style="color:var(--pri-high)">no</span>') +
        (resp.strategy ? ' &middot; Strategy: ' + escHtml(resp.strategy) : '') +
        '</div>';
      if (!resp.headingFound) {
        result.innerHTML = diag + '<span style="color:var(--pri-high)">&#x26A0; ' + escHtml(resp.message) + '</span>';
        return;
      }
      if (resp.data.length === 0) {
        result.innerHTML = diag + '<span style="color:var(--text3)">Heading found but no entries beneath it.</span>';
        return;
      }
      // Render parsed reference cards
      var cards = resp.data.map(function (raw, idx) {
        var parsed = parseRefString(raw);
        var safeId = 'scanref-' + idx;
        return '<div style="border:1px solid var(--border2);border-radius:6px;padding:12px 14px;margin-bottom:10px;background:var(--surface2);">' +
          // Parsed fields
          '<div style="font-size:13px;color:var(--text);font-weight:500;margin-bottom:4px">' + escHtml(parsed.title) + '</div>' +
          '<div style="font-size:11px;color:var(--text3);font-family:\'DM Mono\',monospace;margin-bottom:8px">' +
            (parsed.authors ? escHtml(parsed.authors) : '') +
            (parsed.year    ? ' &middot; ' + escHtml(parsed.year) : '') +
            (parsed.url     ? ' &middot; <a href="' + escHtml(parsed.url) + '" target="_blank" style="color:var(--accent)">' + escHtml(parsed.url.substring(0,50)) + '...</a>' : '') +
          '</div>' +
          // Valid/Invalid toggle
          '<div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">' +
            '<label style="font-size:11px;color:var(--text3);font-family:\'DM Mono\',monospace">Include:</label>' +
            '<button id="' + safeId + '-valid" onclick="setScanRefValid(\'' + safeId + '\',true)" ' +
              'style="padding:2px 8px;border-radius:4px;font-size:11px;cursor:pointer;background:rgba(76,175,118,.2);color:#4caf76;border:1px solid rgba(76,175,118,.4)">Valid</button>' +
            '<button id="' + safeId + '-invalid" onclick="setScanRefValid(\'' + safeId + '\',false)" ' +
              'style="padding:2px 8px;border-radius:4px;font-size:11px;cursor:pointer;background:transparent;color:var(--text3);border:1px solid var(--border2)">Invalid</button>' +
          '</div>' +
          // Notes field
          '<input type="text" id="' + safeId + '-notes" placeholder="Justification for including this source (optional)"' +
            ' style="width:100%;box-sizing:border-box;background:var(--bg);border:1px solid var(--border2);border-radius:4px;padding:5px 8px;color:var(--text);font-size:12px;font-family:\'DM Mono\',monospace;outline:none;margin-bottom:8px">' +
          // Add to sources button
          '<button onclick="addScanRefToSources(\'' + safeId + '\',' + idx + ')" ' +
            'style="padding:5px 12px;background:var(--accent);color:#fff;border:none;border-radius:4px;font-size:12px;font-family:\'Syne\',sans-serif;font-weight:500;cursor:pointer">' +
            'Add to Sources' +
          '</button>' +
          // Store parsed data as JSON attribute
          '<script>window._scanRefs = window._scanRefs || [];window._scanRefs[' + idx + '] = ' + JSON.stringify(parsed) + ';<\/script>' +
        '</div>';
      }).join('');

      result.innerHTML = diag +
        '<div style="margin-bottom:8px;display:flex;align-items:center;gap:12px;">' +
          '<strong style="color:var(--pri-low)">Found ' + resp.data.length + ' reference' + (resp.data.length !== 1 ? 's' : '') + '</strong>' +
          '<button onclick="addAllValidScanRefs(' + resp.data.length + ')" style="padding:4px 10px;background:rgba(76,175,118,.15);color:#4caf76;border:1px solid rgba(76,175,118,.3);border-radius:4px;font-size:11px;cursor:pointer">Add all valid to Sources</button>' +
        '</div>' +
        cards;
    })
    .withFailureHandler(function (e) {
      result.innerHTML = '<span style="color:var(--pri-high)">Failed: ' + escHtml(e.message) + '</span>';
    }).scanDocReferences(docId);
}

function setScanRefValid(safeId, valid) {
  var vBtn = document.getElementById(safeId + '-valid');
  var iBtn = document.getElementById(safeId + '-invalid');
  if (!vBtn || !iBtn) return;
  if (valid) {
    vBtn.style.background = 'rgba(76,175,118,.2)'; vBtn.style.color = '#4caf76'; vBtn.style.borderColor = 'rgba(76,175,118,.4)';
    iBtn.style.background = 'transparent'; iBtn.style.color = 'var(--text3)'; iBtn.style.borderColor = 'var(--border2)';
  } else {
    iBtn.style.background = 'rgba(224,90,90,.15)'; iBtn.style.color = '#e05a5a'; iBtn.style.borderColor = 'rgba(224,90,90,.3)';
    vBtn.style.background = 'transparent'; vBtn.style.color = 'var(--text3)'; vBtn.style.borderColor = 'var(--border2)';
  }
  // Store state on button for bulk-add
  vBtn.dataset.selected = valid ? 'true' : 'false';
}

function addScanRefToSources(safeId, idx) {
  var refs = window._scanRefs || [];
  var parsed = refs[idx];
  if (!parsed) return;
  var notes = (document.getElementById(safeId + '-notes') || {}).value || '';
  var vBtn  = document.getElementById(safeId + '-valid');
  var valid = !vBtn || vBtn.dataset.selected !== 'false'; // default valid
  var source = {
    title:   parsed.title   || '',
    authors: parsed.authors || '',
    year:    parsed.year    || '',
    type:    'journal',
    url:     parsed.url     || '',
    section: '',
    notes:   notes,
  };
  var btn = event.target;
  btn.textContent = 'Adding...'; btn.disabled = true;
  google.script.run
    .withSuccessHandler(function (res) {
      if (res && res.id && !valid) {
        // Mark invalid immediately after add
        google.script.run.setSourceValid(res.id, false, getActor());
      }
      btn.innerHTML = '&#x2713; Added'; btn.style.background = 'rgba(76,175,118,.2)'; btn.style.color = '#4caf76';
    })
    .withFailureHandler(function (e) {
      btn.textContent = 'Failed'; btn.disabled = false;
      alert('Could not add source: ' + e.message);
    }).addSource(source, getActor());
}

function addAllValidScanRefs(count) {
  var refs = window._scanRefs || [];
  var added = 0;
  for (var idx = 0; idx < count; idx++) {
    var safeId = 'scanref-' + idx;
    var vBtn   = document.getElementById(safeId + '-valid');
    // Skip if explicitly marked invalid
    if (vBtn && vBtn.dataset.selected === 'false') continue;
    var parsed = refs[idx];
    if (!parsed) continue;
    var notes  = (document.getElementById(safeId + '-notes') || {}).value || '';
    google.script.run.addSource({
      title:   parsed.title   || '',
      authors: parsed.authors || '',
      year:    parsed.year    || '',
      type:    'journal',
      url:     parsed.url     || '',
      section: '',
      notes:   notes,
    }, getActor());
    added++;
  }
  if (added > 0) {
    setTimeout(function () { loadSources(); }, 1500);
    alert(added + ' source' + (added !== 1 ? 's' : '') + ' queued for adding. Switch to Sources tab to see them.');
  } else {
    alert('No valid references to add. Mark at least one as valid first.');
  }
}

// ── RESEARCH / DORKS ──────────────────────────────────────────
function setEngine(eng) {
  currentEngine = eng;
  var engines = ['google','scholar','semantic','core','shodan'];
  engines.forEach(function (e) {
    var btn = document.getElementById('eng-' + e);
    if (btn) btn.classList.toggle('active', e === eng);
  });
}
function setDork(query, engine) {
  var sq = document.getElementById('search-query');
  if (sq) sq.value = query;
  if (engine) setEngine(engine);
}
function loadDork(btn) {
  var query  = btn.getAttribute('data-query');
  var engine = btn.getAttribute('data-engine') || 'google';
  setDork(query, engine);
}
function useDork(query) {
  var sq = document.getElementById('search-query');
  if (sq) { sq.value = query; sq.focus(); }
}
function runSearch() {
  var sq = document.getElementById('search-query');
  var q  = sq ? sq.value.trim() : '';
  if (!q) return;
  var enc = encodeURIComponent(q);
  var urls = {
    google:   'https://www.google.com/search?q=' + enc,
    scholar:  'https://scholar.google.com/scholar?q=' + enc,
    semantic: 'https://www.semanticscholar.org/search?q=' + enc + '&sort=Relevance',
    core:     'https://core.ac.uk/search?q=' + enc,
    shodan:   'https://www.shodan.io/search?query=' + enc,
  };
  window.open(urls[currentEngine] || urls.google, '_blank');
}
function renderDorkButtons() {
  var container = document.getElementById('dork-container');
  if (!container) return;
  var dorks = (CLIENT_CONFIG.searchDorks || []);
  if (dorks.length === 0) return;
  container.innerHTML = dorks.map(function (group) {
    return '<div class="dork-section">' +
      '<div class="dork-label">' + escHtml(group.label) + '</div>' +
      '<div class="dork-buttons">' +
        (group.dorks || []).map(function (d) {
          var safeQ = (d.query || '').replace(/&/g,'&amp;').replace(/"/g,'&quot;');
          var eng   = d.engine || 'google';
          return '<button class="dork-btn" data-query="' + safeQ + '" data-engine="' + eng + '" onclick="loadDork(this)">' + escHtml(d.label) + '</button>';
        }).join('') +
      '</div></div>';
  }).join('');
}

// Dork builder
function buildDork() {
  var topic     = (document.getElementById('db-topic')    || {}).value || '';
  var phrase    = (document.getElementById('db-phrase')   || {}).value || '';
  var site      = (document.getElementById('db-site')     || {}).value || '';
  var filetype  = (document.getElementById('db-filetype') || {}).value || '';
  var after     = (document.getElementById('db-after')    || {}).value || '';
  var excl      = (document.getElementById('db-exclude')  || {}).value || '';
  var parts = [];
  if (topic)   parts.push(topic);
  if (phrase)  parts.push('"' + phrase + '"');
  if (site)    parts.push('site:' + site);
  if (filetype) parts.push('filetype:' + filetype);
  if (after)   parts.push('after:' + after);
  if (excl)    parts.push('-' + excl);
  var query = parts.join(' ');
  var preview = document.getElementById('db-preview');
  if (preview) preview.textContent = query || 'Your query will appear here...';
  var useBtn = document.getElementById('db-use-btn');
  if (useBtn) useBtn.disabled = !query;
}
function useDorkBuilder() {
  var preview = document.getElementById('db-preview');
  if (!preview || !preview.textContent || preview.textContent === 'Your query will appear here...') return;
  var sq = document.getElementById('search-query');
  if (sq) sq.value = preview.textContent;
}

function toggleDorkRef() {
  var btn  = document.getElementById('dork-ref-btn');
  var body = document.getElementById('dork-ref-body');
  if (btn)  btn.classList.toggle('open');
  if (body) body.classList.toggle('open');
}
function toggleDorkBuilder() {
  var btn  = document.getElementById('dork-builder-btn');
  var body = document.getElementById('dork-builder-body');
  if (btn)  btn.classList.toggle('open');
  if (body) body.classList.toggle('open');
}
function toggleShodanRef() {
  var btn  = document.getElementById('shodan-ref-btn');
  var body = document.getElementById('shodan-ref-body');
  if (btn)  btn.classList.toggle('open');
  if (body) body.classList.toggle('open');
}

// ── AUDIT LOG ─────────────────────────────────────────────────
function loadAuditLog() {
  var c = document.getElementById('audit-container');
  if (!c) return;
  c.innerHTML = '<div class="docs-loading"><div class="spinner"></div> Loading...</div>';
  google.script.run
    .withSuccessHandler(function (entries) { allAuditEntries = entries || []; renderAuditLog(allAuditEntries); })
    .withFailureHandler(function (e) { c.innerHTML = '<div class="audit-empty">Failed: ' + e.message + '</div>'; })
    .getAuditLog();
}
function renderAuditLog(entries) {
  var c = document.getElementById('audit-container');
  if (!c) return;
  if (!entries || entries.length === 0) { c.innerHTML = '<div class="audit-empty">No audit entries found.</div>'; return; }
  c.innerHTML = '<div class="audit-table-wrap"><table class="audit-table"><thead><tr>' +
    '<th>Timestamp</th><th>Editor</th><th>Category</th><th>Action</th><th>Item</th><th>Changed</th>' +
    '</tr></thead><tbody>' +
    entries.map(function (e) {
      return '<tr>' +
        '<td style="white-space:nowrap;font-family:\'DM Mono\',monospace;font-size:11px">' + escHtml(e.timestamp) + '</td>' +
        '<td style="font-size:12px">' + escHtml(e.editor) + '</td>' +
        '<td style="font-family:\'DM Mono\',monospace;font-size:11px">' + escHtml(e.category) + '</td>' +
        '<td style="font-family:\'DM Mono\',monospace;font-size:11px">' + escHtml(e.action) + '</td>' +
        '<td style="max-width:180px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + escHtml(e.entityTitle) + '</td>' +
        '<td style="font-size:11px;color:var(--text3);max-width:200px">' + escHtml(e.fieldsChanged) + '</td>' +
      '</tr>';
    }).join('') + '</tbody></table></div>';
}
function filterAuditLog(query) {
  if (!query) { renderAuditLog(allAuditEntries); return; }
  var q = query.toLowerCase();
  var filtered = allAuditEntries.filter(function (e) {
    return (e.editor + e.category + e.action + e.entityTitle + e.fieldsChanged).toLowerCase().includes(q);
  });
  renderAuditLog(filtered);
}

// ── TAB SWITCHING ─────────────────────────────────────────────
function switchTab(tab, btn) {
  document.querySelectorAll('.tab-panel').forEach(function (p) { p.classList.remove('active'); });
  document.querySelectorAll('.tab-btn').forEach(function (b) { b.classList.remove('active'); });
  var panel = document.getElementById('tab-' + tab);
  if (panel) panel.classList.add('active');
  if (btn)   btn.classList.add('active');
  if (tab === 'docs')    loadDocs();
  if (tab === 'notes')   loadNotes();
  if (tab === 'report')  loadReportSections();
  if (tab === 'sources') loadSources();
  if (tab === 'audit')   loadAuditLog();
}
</script>
