// ============================================================
// Welsford_KanBan — diagnostics.gs
// Version: 4.3
// Editor-only diagnostic tools. Read-only — no side effects.
// Run individual checks or runAllDiagnostics() for a full report.
// Never called from the web app frontend.
// ============================================================

// ============================================================
// MASTER RUNNER
// Run this from the Apps Script editor to get a full report.
// ============================================================
function runAllDiagnostics() {
  Logger.log('');
  Logger.log('============================================================');
  Logger.log('Welsford_KanBan — Diagnostics Report');
  Logger.log(Utilities.formatDate(new Date(), Session.getScriptTimeZone(), 'yyyy-MM-dd HH:mm:ss'));
  Logger.log('============================================================');

  diagCheckAuth();
  diagCheckSpreadsheet();
  diagCheckDocumentsFolder();
  diagCheckSubmissionsFolder();
  diagCheckSectionMatching();
  diagCheckExternalFetch();

  Logger.log('');
  Logger.log('============================================================');
  Logger.log('Diagnostics complete.');
  Logger.log('============================================================');
}

// ============================================================
// AUTH CHECK
// Confirms the executing user and whether they are authorised.
// ============================================================
function diagCheckAuth() {
  Logger.log('');
  Logger.log('--- AUTH ---');
  try {
    const email = Session.getActiveUser().getEmail();
    Logger.log('Executing as: ' + (email || '(empty — script may be running as anonymous)'));
    if (!email) {
      Logger.log('WARNING: Empty email. If the board uses an email allowlist, all requests will be rejected.');
    }
  } catch (e) {
    Logger.log('ERROR: Could not read active user — ' + e.message);
  }
}

// ============================================================
// SPREADSHEET CHECK
// Confirms the spreadsheet is reachable and all expected
// sheets exist with the correct headers.
// ============================================================
function diagCheckSpreadsheet() {
  Logger.log('');
  Logger.log('--- SPREADSHEET ---');
  try {
    const spreadsheet = SpreadsheetApp.openById(SPREADSHEET_ID);
    Logger.log('Spreadsheet: ' + spreadsheet.getName() + ' (' + SPREADSHEET_ID + ')');

    const expectedSheets = [
      SHEET_TASKS, SHEET_MEMBERS, SHEET_DEADLINES, SHEET_NOTES,
      SHEET_AUDIT, SHEET_SUB_SNAP, SHEET_SOURCES, SHEET_WORDCOUNTS,
    ];

    expectedSheets.forEach(function (name) {
      const sh = spreadsheet.getSheetByName(name);
      if (!sh) {
        Logger.log('  MISSING sheet: ' + name);
      } else {
        Logger.log('  OK sheet: ' + name + ' (' + Math.max(0, sh.getLastRow() - 1) + ' data rows)');
      }
    });
  } catch (e) {
    Logger.log('ERROR: Cannot open spreadsheet — ' + e.message);
    Logger.log('Check SPREADSHEET_ID in config.gs.');
  }
}

// ============================================================
// DOCUMENTS FOLDER CHECK
// Confirms the documents folder is reachable and lists all files.
// ============================================================
function diagCheckDocumentsFolder() {
  Logger.log('');
  Logger.log('--- DOCUMENTS FOLDER ---');
  try {
    const folder = DriveApp.getFolderById(DOCUMENTS_FOLDER_ID);
    Logger.log('Folder: ' + folder.getName() + ' (' + DOCUMENTS_FOLDER_ID + ')');

    const files  = folder.getFiles();
    const list   = [];
    while (files.hasNext()) { list.push(files.next()); }
    Logger.log('Files found: ' + list.length);

    list.forEach(function (f) {
      const isDoc = f.getMimeType() === MimeType.GOOGLE_DOCS;
      Logger.log('  ' + (isDoc ? 'GDOC' : 'OTHER (' + f.getMimeType() + ')') + ' — ' + f.getName());
    });

    const nonDocs = list.filter(function (f) { return f.getMimeType() !== MimeType.GOOGLE_DOCS; });
    if (nonDocs.length > 0) {
      Logger.log('WARNING: ' + nonDocs.length + ' non-Google-Doc file(s) found. These will be skipped by compileReport().');
    }
  } catch (e) {
    Logger.log('ERROR: Cannot open documents folder — ' + e.message);
    Logger.log('Check DOCUMENTS_FOLDER_ID in config.gs.');
  }
}

// ============================================================
// SUBMISSIONS FOLDER CHECK
// Confirms the submissions folder is reachable and lists files.
// ============================================================
function diagCheckSubmissionsFolder() {
  Logger.log('');
  Logger.log('--- SUBMISSIONS FOLDER ---');
  try {
    const folder = DriveApp.getFolderById(SUBMISSIONS_FOLDER_ID);
    Logger.log('Folder: ' + folder.getName() + ' (' + SUBMISSIONS_FOLDER_ID + ')');

    const files = folder.getFiles();
    const list  = [];
    while (files.hasNext()) { list.push(files.next()); }
    Logger.log('Files found: ' + list.length);

    list.forEach(function (f) {
      Logger.log('  ' + f.getMimeType() + ' — ' + f.getName() + ' (' + Math.round(f.getSize() / 1024) + ' KB)');
    });
  } catch (e) {
    Logger.log('ERROR: Cannot open submissions folder — ' + e.message);
    Logger.log('Check SUBMISSIONS_FOLDER_ID in config.gs.');
  }
}

// ============================================================
// SECTION MATCHING CHECK
// Runs the same prefix match logic as compileReport() and
// reports hits and misses for every SECTION_CONFIG entry.
// ============================================================
function diagCheckSectionMatching() {
  Logger.log('');
  Logger.log('--- SECTION MATCHING ---');
  try {
    const folder = DriveApp.getFolderById(DOCUMENTS_FOLDER_ID);
    const files  = folder.getFiles();
    const list   = [];
    while (files.hasNext()) { list.push(files.next()); }

    Logger.log('SECTION_CONFIG entries: ' + SECTION_CONFIG.length);
    Logger.log('Files in documents folder: ' + list.length);
    Logger.log('');

    let matched = 0;
    let missing = 0;

    SECTION_CONFIG.forEach(function (sec) {
      const file = list.find(function (f) { return f.getName().startsWith(sec.num); });
      if (file) {
        const isDoc = file.getMimeType() === MimeType.GOOGLE_DOCS;
        Logger.log('  MATCH  "' + sec.num + '" => "' + file.getName() + '"' + (isDoc ? '' : ' [NOT A GDOC — will be skipped]'));
        matched++;
      } else {
        Logger.log('  MISS   "' + sec.num + '" (' + sec.name + ') — no file found with this prefix');
        missing++;
      }
    });

    Logger.log('');
    Logger.log('Result: ' + matched + ' matched, ' + missing + ' missing');
    if (missing > 0) {
      Logger.log('TIP: File names in the documents folder must start with the sec.num value from config.gs.');
      Logger.log('     Example: sec.num "007" matches any file starting with "007".');
    }
  } catch (e) {
    Logger.log('ERROR: Section matching check failed — ' + e.message);
  }
}

// ============================================================
// EXTERNAL FETCH CHECK
// Confirms UrlFetchApp can reach the CrossRef API.
// ============================================================
function diagCheckExternalFetch() {
  Logger.log('');
  Logger.log('--- EXTERNAL FETCH ---');
  try {
    const resp = UrlFetchApp.fetch('https://api.crossref.org/works/10.1126/science.169.3946.635', { muteHttpExceptions: true });
    const code = resp.getResponseCode();
    if (code === 200) {
      Logger.log('CrossRef API: OK (HTTP 200)');
    } else {
      Logger.log('CrossRef API: Unexpected response — HTTP ' + code);
    }
  } catch (e) {
    Logger.log('CrossRef API: FAILED — ' + e.message);
    Logger.log('Check that UrlFetchApp is permitted in your GAS project scopes.');
  }
}
