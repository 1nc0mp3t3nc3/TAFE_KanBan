// ============================================================
// Welsford_KanBan - config.gs
// THE ONLY FILE YOU NEED TO EDIT FOR EACH NEW PROJECT
// ============================================================
// All project-specific values live here. code.gs, index.html,
// app.js, styles.css.html, and login.html read from this file
// and should not need to be modified between projects.
//
// SETUP STEPS:
//  1. Create a new Google Sheet for your project
//  2. Open Extensions > Apps Script from that sheet
//  3. Paste all five files (config.gs, code.gs, index.html,
//     styles.css.html, login.html) into the editor
//  4. Fill in the CONFIG block below
//  5. Run setupSpreadsheet() from the editor once
//  6. Deploy as Web App:
//       Execute as: Me
//       Who has access: Anyone with Google Account
//  7. Share the deployed URL with your group
// ============================================================

const MASTER_CONFIG = {

  // ── BACKEND - never exposed to the frontend ────────────────
  backend: {

    // Google Sheet ID - get from the sheet URL:
    // docs.google.com/spreadsheets/d/SPREADSHEET_ID/edit
    SPREADSHEET_ID: 'YOUR_SPREADSHEET_ID',

    // Google Drive folder ID for member file submissions.
    // Get from the folder URL:
    // drive.google.com/drive/folders/FOLDER_ID
    SUBMISSIONS_FOLDER_ID: 'YOUR_SUBMISSIONS_FOLDER_ID',

    // Google Drive folder ID for collaborative section Google Docs.
    DOCUMENTS_FOLDER_ID: 'YOUR_DOCUMENTS_FOLDER_ID',

    // SHA-256 hash of your group PIN.
    // Leave as empty string '' to disable PIN gate entirely
    // (anyone with the URL can access the board).
    //
    // To generate a hash:
    //   1. Go to https://emn178.github.io/online-tools/sha256.html
    //   2. Type your chosen PIN in the Input field
    //   3. Copy the Output hash string and paste it below
    //
    // Example: PIN "1234" hashes to
    //   "03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4"
    SERVER_PIN_HASH: '',
  },

  // ── FRONTEND - served to the UI via getClientConfig() ──────
  ui: {

    // ── BRANDING ───────────────────────────────────────────────
    // logoText: 2-3 characters shown in the logo badge.
    logoText:        'KB',
    // logoImageUrl: URL to an image to use instead of text.
    // Leave as '' to use logoText.
    logoImageUrl:    '',
    // pageTitle: shown in the browser tab.
    pageTitle:       'My Project Task Board',
    projectName:     'My Project',
    projectSubtitle: 'Project subtitle goes here',

    // ── DRIVE FOLDER URLS ──────────────────────────────────────
    // Full URL (not just ID) used for the "Upload to Drive" button.
    submissionsFolderUrl: 'https://drive.google.com/drive/folders/YOUR_SUBMISSIONS_FOLDER_ID',
    documentsFolderUrl:   'https://drive.google.com/drive/folders/YOUR_DOCUMENTS_FOLDER_ID',

    // ── HEADER CHIPS ───────────────────────────────────────────
    // Small labels shown in the top-right of the header.
    // accent: true makes the chip highlighted in blue.
    headerChips: [
      { label: '2500 words',     accent: false },
      { label: 'Due DD/MM/YYYY', accent: true  },
    ],

    // ── KANBAN COLUMNS ─────────────────────────────────────────
    // These match the Status values stored in the Tasks sheet.
    // Do not change the id values without also updating existing
    // sheet data, as they are used as primary keys.
    columns: [
      { id: 'Not started', label: 'Not started', cls: 'ns'    },
      { id: 'In progress', label: 'In progress', cls: 'ip'    },
      { id: 'In review',   label: 'In review',   cls: 'ir'    },
      { id: 'Done',        label: 'Done',         cls: 'done'  },
      { id: 'Blocked',     label: 'Blocked',      cls: 'block' },
    ],

    // ── REPORT SECTIONS ────────────────────────────────────────
    // num: must match the filename prefix of your Google Docs
    //      in the documents folder. e.g. '01' matches '01 - Intro.gdoc'
    // name: display name shown in the board and report tab.
    // target: word count target (0 = no limit, e.g. References).
    // colorIdx: 0-9, maps to CSS --sec-0 through --sec-9.
    sections: [
      { num: '01', name: 'Introduction',  target: 500,  colorIdx: 0 },
      { num: '02', name: 'Section 2',     target: 800,  colorIdx: 1 },
      { num: '03', name: 'Section 3',     target: 800,  colorIdx: 2 },
      { num: '04', name: 'Conclusion',    target: 300,  colorIdx: 3 },
      { num: '05', name: 'References',    target: 0,    colorIdx: 5 },
    ],

    // Total word count target for the progress bar.
    reportWordTarget: 2500,

    // ── RESEARCH DORKS ─────────────────────────────────────────
    // Pre-built search queries shown in the Research tab.
    // Set to [] to hide the dork buttons entirely.
    // engine: 'google' (default) or 'scholar'
    searchDorks: [
      {
        label: 'Example queries - replace with your topic',
        dorks: [
          { label: 'Scholar: your topic',          query: '"your topic" "key term"',                       engine: 'scholar' },
          { label: 'Gov site: topic reports (PDF)', query: 'site:gov.au "your topic" filetype:pdf'                           },
          { label: 'Exact phrase search',           query: '"exact phrase" "supporting term" Australia'                      },
          { label: 'Exclude terms',                 query: '"your topic" -"term to exclude"'                                 },
        ],
      },
    ],
  },
};

// ============================================================
// BACKEND CONSTANTS - derived from MASTER_CONFIG.
// Used by code.gs. Do not modify.
// ============================================================
const SPREADSHEET_ID        = MASTER_CONFIG.backend.SPREADSHEET_ID;
const SUBMISSIONS_FOLDER_ID = MASTER_CONFIG.backend.SUBMISSIONS_FOLDER_ID;
const DOCUMENTS_FOLDER_ID   = MASTER_CONFIG.backend.DOCUMENTS_FOLDER_ID;
const SERVER_PIN_HASH       = MASTER_CONFIG.backend.SERVER_PIN_HASH;

const SECTION_CONFIG = MASTER_CONFIG.ui.sections.map(function (s) {
  return { num: s.num, name: s.name, target: s.target };
});

const SHEET_TASKS     = 'Tasks';
const SHEET_MEMBERS   = 'Members';
const SHEET_DEADLINES = 'Deadlines';
const SHEET_NOTES     = 'Meeting Notes';
const SHEET_AUDIT     = 'Audit Log';
const SHEET_SUB_SNAP  = 'Submissions Snapshot';
const SHEET_SOURCES   = 'Sources';
const SHEET_WORDCOUNTS = 'Word Counts';

// ============================================================
// SERVE CONFIG TO FRONTEND
// Called by the boot script in index.html on page load.
// ============================================================
function getClientConfig() {
  // spreadsheetId included so the client can build a per-board
  // localStorage key for identity persistence (see app.js KB_IDENTITY_KEY).
  var cfg = JSON.parse(JSON.stringify(MASTER_CONFIG.ui));
  cfg.spreadsheetId = MASTER_CONFIG.backend.SPREADSHEET_ID;
  return cfg;
}
